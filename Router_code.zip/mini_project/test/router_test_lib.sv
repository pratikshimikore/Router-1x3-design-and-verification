class router_base_test extends uvm_test;

	`uvm_component_utils(router_base_test)
	
	router_tb 	   envh;
	source_config  	   src_m_cfg[];	
	destination_config dst_m_cfg[];	
	router_env_config  m_cfg;


	 int no_of_src = 1;
	 int no_of_dst = 3;

         bit has_src_agent  = 1;
         bit has_dst_agent  = 1;
	 bit has_scoreboard = 1;

function new(string name="router_base_test",uvm_component parent);
	super.new(name,parent);
endfunction


function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	
	m_cfg=router_env_config::type_id::create("m_cfg");	
		
	if(has_src_agent)
		m_cfg.src_m_cfg=new[no_of_src];

	if(has_dst_agent)
		m_cfg.dst_m_cfg=new[no_of_dst];



	if (has_src_agent) 
	begin
		src_m_cfg = new[no_of_src];
	
	        foreach(src_m_cfg[i]) 
		begin
                	src_m_cfg[i]=source_config::type_id::create($sformatf("src_m_cfg[%0d]", i));
	  
			if(!uvm_config_db #(virtual router_if)::get(this,"", $sformatf("src_in%0d",i),src_m_cfg[i].vif))
				`uvm_fatal("RAM_BASE_TEST","cannot get()interface vif from uvm_config_db. Have you set() it?") 
               		src_m_cfg[i].is_active = UVM_ACTIVE;
                	
			m_cfg.src_m_cfg[i] = src_m_cfg[i];               
                end
	end

	if (has_dst_agent)
	begin
		dst_m_cfg = new[no_of_dst];
        	        
		foreach(dst_m_cfg[i]) 
		begin
                	dst_m_cfg[i]=destination_config::type_id::create($sformatf("dst_m_cfg[%0d]", i));
                
			if(!uvm_config_db #(virtual router_if)::get(this,"", $sformatf("dst_in%0d",i),dst_m_cfg[i].vif))
				`uvm_fatal("RAM_BASE_TEST","cannot get()interface vif from uvm_config_db. Have you set() it?") 
               		dst_m_cfg[i].is_active = UVM_ACTIVE;
                	
			m_cfg.dst_m_cfg[i] = dst_m_cfg[i];                                 
                end
	end

                m_cfg.no_of_src = no_of_src;
                m_cfg.no_of_dst = no_of_dst;
                m_cfg.has_src_agent  = has_src_agent;
                m_cfg.has_dst_agent  = has_dst_agent;
		m_cfg.has_scoreboard = has_scoreboard;

	uvm_config_db #(router_env_config)::set(this,"*","router_env_config",m_cfg);

	envh=router_tb::type_id::create("envh",this);

endfunction

function void end_of_elaboration_phase(uvm_phase phase);
	super.end_of_elaboration_phase(phase);
	uvm_top.print_topology();
endfunction

endclass   



class src_small_test extends router_base_test;
	`uvm_component_utils(src_small_test)
	bit[1:0] addr;
	normal_seq ns;
	src_small_seqs src_sm;

function new(string name="src_small_test",uvm_component parent);
	super.new(name,parent);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	addr=$urandom%3;
	uvm_config_db #(bit[1:0])::set(this,"*","bit[1:0]",addr);
endfunction

task run_phase(uvm_phase phase);
	src_sm=src_small_seqs::type_id::create("src_sm");
	ns=normal_seq::type_id::create("ns");	
	phase.raise_objection(this);
	repeat(3)
	begin 
	fork
	   src_sm.start(envh.src_agt_top.src_agth[0].src_seqrh);
	   ns.start(envh.dst_top_agt.dst_agth[addr].dst_seqrh);
	join
	end
	phase.drop_objection(this);
endtask

endclass



class src_medium_test extends router_base_test;
	`uvm_component_utils(src_medium_test)
	src_medium_seqs src_me;
	bit[1:0] addr;
	normal_seq ns; 

function new(string name="src_medium_test",uvm_component parent);
	super.new(name,parent);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	addr=$urandom%3;
	uvm_config_db #(bit[1:0])::set(this,"*","bit[1:0]",addr);
endfunction

task run_phase(uvm_phase phase);
	src_me=src_medium_seqs::type_id::create("src_me");
	ns=normal_seq::type_id::create("ns");	
	phase.raise_objection(this);
	repeat(3)
	begin 
	fork
	   src_me.start(envh.src_agt_top.src_agth[0].src_seqrh);
	   ns.start(envh.dst_top_agt.dst_agth[addr].dst_seqrh);
	join
	end
	phase.drop_objection(this);
endtask

endclass


class src_large_test extends router_base_test;
	`uvm_component_utils(src_large_test)
	src_large_seqs src_la;
	bit[1:0] addr;
	normal_seq ns; 

function new(string name="src_large_test",uvm_component parent);
	super.new(name,parent);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	addr=$urandom%3;
	uvm_config_db #(bit[1:0])::set(this,"*","bit[1:0]",addr);
endfunction

task run_phase(uvm_phase phase);
	src_la=src_large_seqs::type_id::create("src_la");
	ns=normal_seq::type_id::create("ns");	
	phase.raise_objection(this);
	repeat(3)
	begin 
	fork
	   src_la.start(envh.src_agt_top.src_agth[0].src_seqrh);
	   ns.start(envh.dst_top_agt.dst_agth[addr].dst_seqrh);
	join
	end
	phase.drop_objection(this);
endtask

endclass