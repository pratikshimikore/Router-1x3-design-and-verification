package router_test_pkg;

import uvm_pkg::*;
`include "uvm_macros.svh"

`include "source_config.sv"
`include "destination_config.sv"
`include "router_env_config.sv"
`include "source_xtn.sv"
`include "destination_xtn.sv"

`include "router_src_seqs.sv"
`include "router_src_driver.sv"
`include "router_src_monitor.sv"
`include "router_src_sequencer.sv"
`include "router_src_agent.sv"
`include "router_src_agent_top.sv"

//`include "read_xtn.sv"
`include "router_dst_seqs.sv"
`include "router_dst_monitor.sv"
`include "router_dst_sequencer.sv"
`include "router_dst_driver.sv"
`include "router_dst_agent.sv"
`include "router_dst_agent_top.sv"

`include "router_scoreboard.sv"

`include "router_tb.sv"
`include "router_test_lib.sv"

endpackage
