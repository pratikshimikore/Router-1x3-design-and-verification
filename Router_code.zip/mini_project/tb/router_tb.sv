class router_tb extends uvm_env;

	`uvm_component_utils(router_tb)

	router_env_config m_cfg;
	router_src_agent_top src_agt_top;	
	router_dst_agent_top dst_top_agt;
	router_scoreboard scoreboard;	

function new(string name="router_tb",uvm_component parent); 
	super.new(name,parent);
endfunction


function void build_phase(uvm_phase phase);
	super.build_phase(phase);

	if(!uvm_config_db#(router_env_config)::get(this,"","router_env_config",m_cfg))
		`uvm_fatal("ROUTER_TB","failed to get() m_cfg handle of router_env_config")

	if(m_cfg.has_src_agent)
	begin
		src_agt_top=router_src_agent_top::type_id::create("src_agt_top",this);
		foreach(m_cfg.src_m_cfg[i])
			uvm_config_db#(source_config)::set(this,$sformatf("src_agt_top.src_agth[%0d]*",i),"source_config",m_cfg.src_m_cfg[i]);
	end	

	if(m_cfg.has_dst_agent)
	begin
		dst_top_agt=router_dst_agent_top::type_id::create("dst_top_agt",this);		
		foreach(m_cfg.dst_m_cfg[i])
			uvm_config_db#(destination_config)::set(this,$sformatf("dst_top_agt.dst_agth[%0d]*",i),"destination_config",m_cfg.dst_m_cfg[i]);
	end

	if(m_cfg.has_scoreboard)
		scoreboard=router_scoreboard::type_id::create("scoreboard",this);

endfunction


function void connect_phase(uvm_phase phase);
	super.connect_phase(phase);
	for(int i=0;i<m_cfg.no_of_src;i++)
		src_agt_top.src_agth[i].src_monh.monitor_port.connect(scoreboard.src_fifo[i].analysis_export);
	for(int i=0;i<m_cfg.no_of_dst;i++)
		dst_top_agt.dst_agth[i].dst_monh.monitor_port.connect(scoreboard.dst_fifo[i].analysis_export);
endfunction

endclass
