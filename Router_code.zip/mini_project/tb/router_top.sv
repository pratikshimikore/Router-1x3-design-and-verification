module top;

	import router_test_pkg::*;
	import uvm_pkg::*;

	bit clock;
	always 
		#10 clock=!clock;

	router_if src_in0(clock);
	router_if src_in1(clock);
	router_if dst_in0(clock);
	router_if dst_in1(clock);
	router_if dst_in2(clock);

router_top DUV(.clock(clock),
			.pkt_valid(src_in0.pkt_valid),
			.err(src_in0.error),
			.busy(src_in0.busy),
			.resetn(src_in0.resetn),
			.data_in(src_in0.data_in),
			.vld_out_0(dst_in0.valid_out),
			.vld_out_1(dst_in1.valid_out),
			.vld_out_2(dst_in2.valid_out),
			.read_enb_0(dst_in0.read_enb),
			.read_enb_1(dst_in1.read_enb),
			.read_enb_2(dst_in2.read_enb),
			.data_out_0(dst_in0.data_out),
			.data_out_1(dst_in1.data_out),
			.data_out_2(dst_in2.data_out)); 
       	initial 
		begin

			/*`ifdef VCS
         		$fsdbDumpvars(0, top);
        		`endif*/

			uvm_config_db #(virtual router_if)::set(null,"*","src_in0",src_in0);
			uvm_config_db #(virtual router_if)::set(null,"*","src_in1",src_in1);
			uvm_config_db #(virtual router_if)::set(null,"*","dst_in0",dst_in0);
			uvm_config_db #(virtual router_if)::set(null,"*","dst_in1",dst_in1);
			uvm_config_db #(virtual router_if)::set(null,"*","dst_in2",dst_in2);
			
			run_test();
		end   
endmodule




	






































