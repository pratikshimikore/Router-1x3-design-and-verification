class router_scoreboard extends uvm_scoreboard;

	`uvm_component_utils(router_scoreboard)

	router_env_config m_cfg;
	source_xtn 	  src_data;
	destination_xtn   dst_data;
	
	uvm_tlm_analysis_fifo #(source_xtn) 	src_fifo[];
	uvm_tlm_analysis_fifo #(destination_xtn) dst_fifo[];

	int data_verified;

covergroup src_cg;
	option.per_instance=1;
	SRC_ADDR : coverpoint src_data.header[1:0] { bins addr0={0};
						 bins addr1={1};
						 bins addr2={2}; }
	
	SRC_LENGTH : coverpoint src_data.header[7:2] {bins small_pkt={[1:15]};
						  bins medium_pkt={[16:30]}; 
						  bins large_pkt={[31:63]};}
	SRC_ERROR : coverpoint src_data.error {bins error={0,1};}

	SRC_CROSS : cross SRC_ADDR,SRC_LENGTH,SRC_ERROR;
endgroup

covergroup dst_cg;
	option.per_instance=1;
	DST_ADDR : coverpoint dst_data.header[1:0] { bins addr0={0};
						 bins addr1={1};
						 bins addr2={2}; }
	
	DST_LENGTH : coverpoint dst_data.header[7:2] {bins small_pkt={[1:15]};
						  bins medium_pkt={[16:30]}; 
						  bins large_pkt={[31:63]};}
	DST_ERROR : coverpoint dst_data.error {bins error={0,1};}

	DST_CROSS : cross DST_ADDR,DST_LENGTH,DST_ERROR;
endgroup

function new(string name="router_scoreboard",uvm_component parent);
	super.new(name,parent);
	src_cg=new();
	dst_cg=new();
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	if(!uvm_config_db#(router_env_config)::get(this,"","router_env_config",m_cfg))
		`uvm_fatal(get_full_name,"config failed")
	
	src_fifo=new[m_cfg.no_of_src];
	foreach(src_fifo[i])
		src_fifo[i]=new($sformatf("src_fifo[%0d]",i),this);

	dst_fifo=new[m_cfg.no_of_dst];
	foreach(dst_fifo[i])
		dst_fifo[i]=new($sformatf("dst_fifo[%0d]",i),this);
endfunction

task run_phase(uvm_phase phase);
super.run_phase(phase);
	fork 
	   begin
		forever
		begin
		src_fifo[0].get(src_data);
		`uvm_info("ROUTER_SCOREBOARD",$sformatf("printing from monitor \n %s", src_data.sprint()),UVM_LOW) 
		src_cg.sample();
		end
	   end

	   begin
		fork

		   begin
			forever
			begin
			dst_fifo[0].get(dst_data);
			`uvm_info("ROUTER_SCOREBOARD",$sformatf("printing from monitor \n %s", dst_data.sprint()),UVM_LOW) 
			compare(src_data,dst_data);
			dst_cg.sample();
			end
		   end

		   begin
			forever
			begin
			dst_fifo[1].get(dst_data);
			`uvm_info("ROUTER_SCOREBOARD",$sformatf("printing from monitor \n %s", dst_data.sprint()),UVM_LOW) 
			compare(src_data,dst_data);
			dst_cg.sample();
			end
		   end
		   
		   begin
			forever
			begin
			dst_fifo[0].get(dst_data);
			`uvm_info("ROUTER_SCOREBOARD",$sformatf("printing from monitor \n %s", dst_data.sprint()),UVM_LOW) 
			compare(src_data,dst_data);
			dst_cg.sample();
			end
		   end

		join_any
		disable fork;
	   end
	join
endtask

task compare(source_xtn sd,destination_xtn dd);

	if(sd.header==dd.header)
		$display("Source_Header Matched with Destination_Header\n");
	else
		$display("Source_Header Not Matched with Destination_Header\n");

	if(sd.payload==dd.payload)
		$display("Source_Payload Matched with Destination_Payload\n");
	else
		$display("Source_Payload Not Matched with Destination_Payload\n");
		
	if(sd.parity==dd.parity)
		$display("Source_Parity Matched with Destination_Parity\n");
	else
		$display("Source_Parity Not Matched with Destination_Parity\n");

	data_verified++;

endtask

endclass
		

	
	