class router_env_config extends uvm_object;
	
	 int no_of_src = 1;
	 int no_of_dst = 1;

         bit has_src_agent  = 1;
         bit has_dst_agent  = 1;
	 bit has_scoreboard = 1;
	
	source_config src_m_cfg[];	
	destination_config dst_m_cfg[];	

	`uvm_object_utils(router_env_config)

function new(string name="router_env_config");
	super.new(name);
endfunction

endclass
