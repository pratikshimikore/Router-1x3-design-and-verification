class router_dst_agent extends uvm_agent;

	destination_config dst_m_cfg;
	router_dst_driver dst_drvh;
	router_dst_monitor dst_monh;
	router_dst_sequencer dst_seqrh;

	
	`uvm_component_utils(router_dst_agent)

function new(string name="router_dst_agent",uvm_component parent);
	super.new(name,parent);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	if(!uvm_config_db#(destination_config)::get(this,"","destination_config",dst_m_cfg))
		`uvm_fatal("ROUTER_WR_DRIVER","cannot get() dst_m_cfg from router_dst_config class")

	dst_monh=router_dst_monitor::type_id::create("dst_monh",this);
	if(dst_m_cfg.is_active==UVM_ACTIVE)
		begin
		dst_drvh=router_dst_driver::type_id::create("dst_drvh",this);
		dst_seqrh=router_dst_sequencer::type_id::create("dst_seqrh",this);
		end
endfunction

function void connect_phase(uvm_phase phase);
	super.connect_phase(phase);
	if(dst_m_cfg.is_active==UVM_ACTIVE)
		dst_drvh.seq_item_port.connect(dst_seqrh.seq_item_export);
endfunction

endclass

	

