	class destination_config extends uvm_object;
	`uvm_object_utils(destination_config)
	
	uvm_active_passive_enum is_active;
	virtual router_if vif;
	
	function new(string name="destination_config");
		super.new(name);
	endfunction
	endclass
