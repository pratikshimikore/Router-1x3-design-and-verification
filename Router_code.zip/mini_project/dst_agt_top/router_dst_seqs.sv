class router_dst_seqs extends uvm_sequence #(destination_xtn);
	`uvm_object_utils(router_dst_seqs)
	
function new(string name="router_dst_seqs");
	super.new(name);
endfunction

endclass

	
class normal_seq extends router_dst_seqs;
	`uvm_object_utils(normal_seq)

function new(string name="normal_seq");
	super.new(name);
endfunction

task body();
			
//repeat(3)
	begin
	req=destination_xtn::type_id::create("req");
	start_item(req);
	assert(req.randomize() with{no_of_cycle inside{[1:29]};})
	finish_item(req);
	end
	
endtask
endclass

