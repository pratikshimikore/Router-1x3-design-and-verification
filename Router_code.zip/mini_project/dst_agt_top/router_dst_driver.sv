class router_dst_driver extends uvm_driver #(destination_xtn);

	destination_config dst_m_cfg;
	virtual router_if.DST_DRV_MP vif;
	destination_xtn xtn;
	`uvm_component_utils(router_dst_driver)

function new(string name="router_dst_driver",uvm_component parent);
	super.new(name,parent);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	
	if(!uvm_config_db#(destination_config)::get(this,"","destination_config",dst_m_cfg))
		`uvm_fatal("ROUTER_DST_DRIVER","cannot get() dst_m_cfg from router_dst_config class")
endfunction

function void connect_phase(uvm_phase phase);
	super.connect_phase(phase);
	
	vif=dst_m_cfg.vif;
endfunction

task run_phase (uvm_phase phase);
forever
		begin
req=destination_xtn::type_id::create("req");	
			seq_item_port.get_next_item(req);
			//req.print();
			get_from_dut(req);
			seq_item_port.item_done();
		end
endtask

task get_from_dut(destination_xtn xtn);

	wait(vif.dst_drv.valid_out==1) ;
	repeat(xtn.no_of_cycle)
   	@(vif.dst_drv);
	vif.dst_drv.read_enb<=1'b1;

	wait(vif.dst_drv.valid_out==0) ;
   	@(vif.dst_drv);
	vif.dst_drv.read_enb<=1'b0;
   
	`uvm_info("ROUTER_DST_DRIVER",$sformatf("printing from driver \n %s", xtn.sprint()),UVM_LOW) 
	repeat(3)
	@(vif.dst_drv);

endtask
endclass
	
