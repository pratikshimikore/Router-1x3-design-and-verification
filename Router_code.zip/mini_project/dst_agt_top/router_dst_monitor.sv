class router_dst_monitor extends uvm_monitor;

	destination_config dst_m_cfg;
	virtual router_if.DST_MON_MP vif;
	destination_xtn xtn;
	uvm_analysis_port#(destination_xtn) monitor_port;

	`uvm_component_utils(router_dst_monitor)

function new(string name="router_dst_monitor",uvm_component parent);
	super.new(name,parent);
	monitor_port=new("monitor_port",this);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);

	if(!uvm_config_db#(destination_config)::get(this,"","destination_config",dst_m_cfg))
		`uvm_fatal("ROUTER_DST_MONITOR","cannot get() dst_m_cfg from router_dst_config class")
endfunction

function void connect_phase(uvm_phase phase);
	super.connect_phase(phase);
	
	vif=dst_m_cfg.vif;
endfunction

task run_phase (uvm_phase phase);
	forever
		collect_sample();
endtask

task collect_sample();
	repeat(1)
	   @(vif.dst_mon);

	xtn=destination_xtn::type_id::create("xtn");
	wait(vif.dst_mon.read_enb==1'b1) 
   	@(vif.dst_mon);
	xtn.header=vif.dst_mon.data_out;
	xtn.payload=new[xtn.header[7:2]];
	
	@(vif.dst_mon);
	foreach(xtn.payload[i])
	begin
	   xtn.payload[i]=vif.dst_mon.data_out;
  	   @(vif.dst_mon);	   
	end

	xtn.parity=vif.dst_mon.data_out;	

	repeat(1)
	   @(vif.dst_mon);
	monitor_port.write(xtn);
	//`uvm_info("ROUTER_DST_MONITOR",$sformatf("printing from monitor \n %s", xtn.sprint()),UVM_LOW) 
	`uvm_info("ROUTER_DST_MONITOR","dst_monitor",UVM_LOW) 

	xtn.print();
endtask

endclass

