class router_src_seqs extends uvm_sequence #(source_xtn);
	
	`uvm_object_utils(router_src_seqs)

function new(string name="router_src_seqs");
	super.new(name);
endfunction

endclass


class src_small_seqs extends router_src_seqs;
		
	 bit[1:0] addr;	
	`uvm_object_utils(src_small_seqs)

function new(string name="src_small_seqs");
	super.new(name);
endfunction

task body();
	bit [1:0]addr;
	if(!uvm_config_db #(bit[1:0])::get(null,get_full_name(),"bit[1:0]",addr))
		`uvm_fatal(get_type_name,"cant get addr have you set it")

	begin
		req=source_xtn::type_id::create("req");
		start_item(req);
		assert(req.randomize() with{header[7:2] inside{[1:14]};header[1:0]== addr;})
		//req.print;
		finish_item(req); 
	end
endtask

endclass


class src_medium_seqs extends router_src_seqs;
		
	 bit[1:0] addr;	
	`uvm_object_utils(src_medium_seqs)

function new(string name="src_medium_seqs");
	super.new(name);
endfunction

task body();
	bit [1:0]addr;
	if(!uvm_config_db #(bit[1:0])::get(null,get_full_name(),"bit[1:0]",addr))
		`uvm_fatal(get_type_name,"cant get addr have you set it")

	begin
		req=source_xtn::type_id::create("req");
		start_item(req);
		assert(req.randomize() with{header[7:2] inside{[15:30]};header[1:0]== addr;})
		//req.print;
		finish_item(req); 
	end
endtask

endclass


class src_large_seqs extends router_src_seqs;
		
	 bit[1:0] addr;	
	`uvm_object_utils(src_large_seqs)

function new(string name="src_large_seqs");
	super.new(name);
endfunction

task body();
	bit [1:0]addr;
	if(!uvm_config_db #(bit[1:0])::get(null,get_full_name(),"bit[1:0]",addr))
		`uvm_fatal(get_type_name,"cant get addr have you set it")

	begin
		req=source_xtn::type_id::create("req");
		start_item(req);
		assert(req.randomize() with{header[7:2] inside{[31:62]};header[1:0]== addr;})
		//req.print;
		finish_item(req); 
	end
endtask

endclass
