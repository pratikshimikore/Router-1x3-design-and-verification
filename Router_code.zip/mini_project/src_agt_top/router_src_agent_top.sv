class router_src_agent_top extends uvm_env;
	
	router_env_config m_cfg;
	
	router_src_agent src_agth[];

`uvm_component_utils(router_src_agent_top)

function new(string name="router_src_agent_top",uvm_component parent);
	super.new(name,parent);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	if(!uvm_config_db #(router_env_config)::get(this,"","router_env_config",m_cfg))
		`uvm_fatal("ROUTER_AGENT_TOP","failed to get() m_cfg handle of router_env_config")
		
	if(m_cfg.has_src_agent)
	begin
		src_agth=new[m_cfg.no_of_src];
		foreach(src_agth[i])
		src_agth[i]=router_src_agent::type_id::create($sformatf("src_agth[%0d]",i),this);
	end
endfunction

endclass
