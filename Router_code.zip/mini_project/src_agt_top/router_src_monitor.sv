class router_src_monitor extends uvm_monitor;

	source_config   src_m_cfg;
	source_xtn      xtn;
	virtual         router_if.SRC_MON_MP vif;
	uvm_analysis_port#(source_xtn) monitor_port;

	`uvm_component_utils(router_src_monitor)

function new(string name="router_src_monitor",uvm_component parent);
	super.new(name,parent);
	monitor_port=new("monitor_port",this);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);

	if(!uvm_config_db#(source_config)::get(this,"","source_config",src_m_cfg))
		`uvm_fatal("ROUTER_WR_DRIVER","cannot get() src_m_cfg from router_src_config class")
endfunction

function void connect_phase(uvm_phase phase);
	super.connect_phase(phase);
	
	vif=src_m_cfg.vif;
endfunction

task run_phase(uvm_phase phase);
	xtn=source_xtn::type_id::create("xtn");
	forever
	  sample();
endtask

task sample();

	wait(vif.src_mon.busy==0);
	wait(vif.src_mon.pkt_valid==1);
	xtn.header=vif.src_mon.data_in;
	xtn.payload=new[xtn.header[7:2]];
	
	@(vif.src_mon)
	foreach(xtn.payload[i])
	begin
      	   wait(vif.src_mon.busy==0);
	   xtn.payload[i]=vif.src_mon.data_in;
	   @(vif.src_mon);
	end

	wait(vif.src_mon.pkt_valid==0);
	xtn.parity=vif.src_mon.data_in;	

	repeat(2)
	@(vif.src_mon)
	   xtn.error=vif.src_mon.error;	
	monitor_port.write(xtn);
	
    `uvm_info("ROUTER_SRC_MONITOR",$sformatf("printing from monitor \n %s", xtn.sprint()),UVM_LOW) 
	/*repeat(0)
	   @(vif.src_mon);*/

endtask

endclass

