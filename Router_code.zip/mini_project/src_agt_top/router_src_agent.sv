class router_src_agent extends uvm_agent;

	source_config src_m_cfg;
	router_src_driver src_drvh;
	router_src_monitor src_monh;
	router_src_sequencer src_seqrh;

	
	`uvm_component_utils(router_src_agent)

function new(string name="router_src_agent",uvm_component parent);
	super.new(name,parent);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	if(!uvm_config_db#(source_config)::get(this,"","source_config",src_m_cfg))
		`uvm_fatal("ROUTER_WR_DRIVER","cannot get() src_m_cfg from router_src_config class")

	src_monh=router_src_monitor::type_id::create("src_monh",this);
	if(src_m_cfg.is_active==UVM_ACTIVE)
		begin
		src_drvh=router_src_driver::type_id::create("src_drvh",this);
		src_seqrh=router_src_sequencer::type_id::create("src_seqrh",this);
		end
endfunction

function void connect_phase(uvm_phase phase);
	super.connect_phase(phase);
	if(src_m_cfg.is_active==UVM_ACTIVE)
		src_drvh.seq_item_port.connect(src_seqrh.seq_item_export);
endfunction

endclass

	

