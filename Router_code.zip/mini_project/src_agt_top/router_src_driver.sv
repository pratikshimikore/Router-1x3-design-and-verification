class router_src_driver extends uvm_driver #(source_xtn);

	source_config src_m_cfg;
	virtual router_if.SRC_DRV_MP vif;

	`uvm_component_utils(router_src_driver)

function new(string name="router_src_driver",uvm_component parent);
	super.new(name,parent);
endfunction

function void build_phase(uvm_phase phase);
	super.build_phase(phase);
	
	if(!uvm_config_db#(source_config)::get(this,"","source_config",src_m_cfg))
		`uvm_fatal("ROUTER_SRC_DRIVER","cannot get() src_m_cfg from router_src_config class")
endfunction

function void connect_phase(uvm_phase phase);
	super.connect_phase(phase);
	
	vif=src_m_cfg.vif;
endfunction

task run_phase(uvm_phase phase);
    @(vif.src_drv);
	vif.src_drv.resetn<=1'b0;
    repeat(1)
    @(vif.src_drv);
	vif.src_drv.resetn<=1'b1;
	
	req=source_xtn::type_id::create("req");
    forever		
	begin
	seq_item_port.get_next_item(req);
	send_to_dut(req);
	//req.print();
	seq_item_port.item_done(req);
	end
endtask

task send_to_dut(source_xtn xtn);


	
  //  @(vif.src_drv);
	wait(vif.src_drv.busy==0);
	vif.src_drv.pkt_valid<=1'b1;
	vif.src_drv.data_in<=xtn.header;

 	@(vif.src_drv);
	foreach(xtn.payload[i])
		begin
		wait(vif.src_drv.busy==0);
		vif.src_drv.data_in<=xtn.payload[i];			
		@(vif.src_drv);
		end
	vif.src_drv.pkt_valid<=1'b0;
	vif.src_drv.data_in<=xtn.parity;

    `uvm_info("ROUTER_SRC_DRIVER",$sformatf("printing from driver \n %s", xtn.sprint()),UVM_LOW) 
	repeat(3)
	   @(vif.src_drv);
	

endtask	
endclass
	
