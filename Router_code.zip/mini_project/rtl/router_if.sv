interface router_if(input bit clock);
logic resetn,busy,error,pkt_valid,read_enb,valid_out;
logic [7:0]data_in,data_out;

clocking src_drv @(posedge clock);
default input#1 output#0;
	input busy,error;
	output data_in;
	output pkt_valid;
	output resetn;
endclocking

clocking src_mon @(posedge clock);
default input#1 output#0;
	input busy,error,pkt_valid,resetn;
	input data_in;
endclocking

clocking dst_drv @(posedge clock);
default input#1 output#0;
	input valid_out;
	output read_enb;
endclocking

clocking dst_mon @(posedge clock);
default input#1 output#0;
	input valid_out;
	input read_enb;
	input data_out;
endclocking

	
	modport SRC_DRV_MP(clocking src_drv);
	modport SRC_MON_MP(clocking src_mon);
	modport DST_DRV_MP(clocking dst_drv);
	modport DST_MON_MP(clocking dst_mon);

endinterface

